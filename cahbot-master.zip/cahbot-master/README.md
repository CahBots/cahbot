# CahBot

#### ***A small Discord bot with loads of potential***

Heyo, this is CahBot, a small Discord bot with- wait, I'm repeating myself here. Uhh...

#### **CahBot:** A bot that kinda sucks

Wait, no, that's bad to say

Hold on...

#### **CahBot:** A bot that kinda sucks but is being worked on every day

Better

Anyways, here's the current command list (literally just copy & pasted from the command list)

 (upon saying "CB prefix") reminds you the prefix
 
 ^about: Shows you some info about CB, or something
 
 ^rnumber <Number> <Other Number>: Gives you a random number
 
 ^help: Shows this, obviously
 
 ^flip: flips a coin, what else did you expect?
 
 ^ping: Used to show response time
 
 ^invite: Gives you a link to invite me to your own server!
 
 ^die: Shuts me down, only Cah can use this command
 
 ^roll: Rolls a number between 1 and 6
 
 ^eval: Like you don't know what eval commands do
 
 ^donate: Want to donate? That's great! This command gives you a link for PayPal donations
 
 ^update: Gives you the latest CB update
 
 ^say: Makes CB say something, you need the manage messages perm tho
 
#### **Why is this repo here, you may ask**
 
 Well, it's a pretty easy way to transfer code from my PC to my VPS, that's the only reason. But if you want, you can use some of the code
