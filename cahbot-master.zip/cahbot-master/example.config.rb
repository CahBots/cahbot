configatron.token = 'YOUR_TOKEN'
